import "./scss/main.scss";
import "./scss/itc-slider.css";
import "./modules/itc-slider";
import './modules/script';