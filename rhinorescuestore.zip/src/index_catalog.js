import "./scss/main.scss";
import "./scss/catalog.scss";
import "./scss/itc-slider.css";
import "./modules/itc-slider";
import './modules/catalog';
import './modules/script';